$(document).ready(function(){
var tableDetails = users;
var useradd_inprogress = false;
console.log(users);
var table1Body = $('table');		
	$(tableDetails).each(function (inx,val) {
			var trLast = table1Body.find("tr:last");
			var trNew = trLast.clone();
			var tds = trNew.find('td:eq(0)').html(val.name);
			var tds = trNew.find('td:eq(1)').html(val.phone);
			var tds = trNew.find('td:eq(2)').html(val.title);
			var tds = trNew.find('td:eq(3)').html(val.office);
			trLast.after(trNew);
			//Console.log..
		});		
	
		// Add Function
		function Add(){
		if(useradd_inprogress == false)
		{
			//Console.log "adding new user"
			useradd_inprogress = true;
			$("table tbody").append(
				"<tr>"+
				"<td><input type='text'/></td>"+
				"<td><input type='text'/></td>"+
				"<td><input type='text'/></td>"+
				"<td><input type='text'/></td>"+
				"<td><img src='images/Save.png' class='btnSave' alt='Save' title='Save'><img src='images/Delete.png' class='btnDelete' alt='Delete' title='Delete'/></td>"+
				"</tr>");
		
			$(".btnSave").bind("click", Save);		
			$(".btnDelete").bind("click", Delete);
		}
		else
		{
			alert("New user being added");
		}
	};
	
	//Edit Function
	function Edit(){
		//if user add is in progress dont fiddle with other user data
		if(useradd_inprogress==false)
		{
			var par = $(this).parent().parent(); 
			var tdName = par.children("td:nth-child(1)");
			var tdTelephone = par.children("td:nth-child(2)");
			var tdTitle = par.children("td:nth-child(3)");
			var tdOffice = par.children("td:nth-child(4)");
			var tdActions = par.children("td:nth-child(5)");

			tdName.html("<input type='text' id='txtNome' value='"+tdName.html()+"'/>");
			tdTelephone.html("<input type='text' id='txtTelefone' value='"+tdTelephone.html()+"'/>");
			tdTitle.html("<input type='text' id='txtEmail' value='"+tdTitle.html()+"'/>");
			tdOffice.html("<input type='text' id='txtOffice' value='"+tdOffice.html()+"'/>");
			tdActions.html("<img src='images/Save.png' class='btnSave' alt='Save' title='Save'/>");

			$(".btnSave").bind("click", Save);
			$(".btnEdit").bind("click", Edit);
			$(".btnDelete").bind("click", Delete);
		}
	};
	
	//Save function
	function Save(){
			//Console.log "saving user data: {DATA}"
		var par = $(this).parent().parent(); //tr
		var tdName = par.children("td:nth-child(1)");
		var tdTelephone = par.children("td:nth-child(2)");
		var tdTitle = par.children("td:nth-child(3)");
		var tdOffice = par.children("td:nth-child(4)");
		var tdActions = par.children("td:nth-child(5)");
		if(tdName==="" || tdTelephone==="" || tdTitle==="" || tdOffice==="")
		//if(!tdName || !tdTelephone || !tdTitle || !tdOffice)
		{
			alert("Please provide appropriate values");
		}
		else
		{
			tdName.html(tdName.children("input[type=text]").val());
			tdTelephone.html(tdTelephone.children("input[type=text]").val());
			tdTitle.html(tdTitle.children("input[type=text]").val());
			tdOffice.html(tdOffice.children("input[type=text]").val());
			tdActions.html("<img src='images/Edit.png' class='btnEdit' alt='Edit' title='Edit'/><img src='images/Delete.png' class='btnDelete' alt='Delete' title='Delete'/>");
			useradd_inprogress=false;
			$(".btnEdit").bind("click", Edit);
			$(".btnDelete").bind("click", Delete);
		}
	};
	
	//Delete function
	function Delete(){
		var par = $(this).parent().parent(); //tr
			//Console.log "deleted user data: {DATA}"
		par.remove();
	};

	$(".btnEdit").bind("click", Edit);
	$(".btnDelete").bind("click", Delete);
	$("#btnAdd").bind("click", Add);	
		
});


